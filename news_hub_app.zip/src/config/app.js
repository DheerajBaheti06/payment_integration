export const APP_CONFIG = {
  name: "NewsHub",
  description: "Your trusted source for latest news and updates",
  // Add other app-wide configurations here
};
