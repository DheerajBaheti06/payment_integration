"use client";

import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { APP_CONFIG } from "@/config/app";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Sun, Moon } from "lucide-react";

export default function HomePage() {
  const { data: session, status } = useSession();
  const [isLoading, setIsLoading] = useState(true);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    console.log("Session status:", status);
    console.log("Session data:", session);
    if (status !== "loading") {
      setIsLoading(false);
    }
  }, [status, session]);

  if (isLoading) {
    return null;
  }

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-950 dark:to-gray-900 text-gray-900 dark:text-gray-100">
      {/* Navbar */}
      <nav className="bg-white shadow-sm dark:bg-gray-900 dark:border-b dark:border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <Link
              href="/"
              className="text-xl font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
            >
              {APP_CONFIG.name}
            </Link>
            <div className="flex items-center gap-4">
              {/* Theme Toggle Button */}
              <Button
                variant="outline"
                size="icon"
                onClick={toggleTheme}
                className="h-10 w-10 rounded-full border-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-200"
              >
                {theme === "dark" ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-gray-700" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
              {session ? (
                <Link
                  href="/dashboard"
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium"
                >
                  Dashboard
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="px-4 py-2 border transition-colors border-gray-300 text-gray-700 rounded-md hover:border-blue-600 hover:text-blue-600 dark:border-gray-700 dark:text-gray-300 dark:hover:border-blue-400 dark:hover:text-blue-400"
                  >
                    Login
                  </Link>
                  <Link
                    href="/signup"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors ml-2"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            {!session && (
              <div className="flex justify-center gap-4 mb-12">
                <Link
                  href="/signup"
                  className="px-8 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 transition-colors text-lg"
                >
                  Get Started
                </Link>
                <Link
                  href="/pricing"
                  className="px-8 py-3 border border-gray-300 text-gray-700 rounded-md hover:border-blue-600 hover:text-blue-600 transition-colors text-lg dark:border-gray-700 dark:text-gray-300 dark:hover:border-blue-400 dark:hover:text-blue-400"
                >
                  View Pricing
                </Link>
              </div>
            )}

            {/* News Section */}
            <div className="bg-white rounded-xl shadow-sm p-8 dark:bg-gray-900 dark:border dark:border-gray-800">
              {!session ? (
                <div className="text-center mb-8">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 dark:bg-blue-950 dark:border-blue-800">
                    <h2 className="text-2xl font-bold text-blue-700 mb-3 dark:text-blue-300">
                      🔒 Login Required
                    </h2>
                    <p className="text-blue-600 mb-4 dark:text-blue-200">
                      To access the latest news and updates, please log in to
                      your account or create a new one.
                    </p>
                    <div className="flex justify-center gap-4">
                      <Link
                        href="/login"
                        className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 transition-colors"
                      >
                        Login Now
                      </Link>
                      <Link
                        href="/signup"
                        className="px-6 py-2 border border-blue-600 text-blue-600 rounded-md hover:bg-blue-50 transition-colors dark:border-blue-400 dark:text-blue-400 dark:hover:bg-blue-900"
                      >
                        Create Account
                      </Link>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4 dark:text-gray-200">
                    What You'll Get Access To:
                  </h3>
                </div>
              ) : (
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-gray-800 mb-4 dark:text-gray-100">
                    Stay Updated with Latest News
                  </h2>
                  <p className="text-gray-600 dark:text-gray-300">
                    Get real-time updates and insights about industry trends,
                    security updates, and platform enhancements.
                  </p>
                </div>
              )}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-6 rounded-lg dark:bg-gray-800 dark:border dark:border-gray-700">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-blue-600 text-xl dark:text-blue-400">
                      📰
                    </span>
                    <h3 className="text-lg font-semibold dark:text-gray-100">
                      Latest Updates
                    </h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300">
                    Stay informed about the latest features, security patches,
                    and improvements to our platform.
                  </p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg dark:bg-gray-800 dark:border dark:border-gray-700">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-blue-600 text-xl dark:text-blue-400">
                      🔔
                    </span>
                    <h3 className="text-lg font-semibold dark:text-gray-100">
                      Real-time Notifications
                    </h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300">
                    Receive instant notifications about important updates and
                    changes that affect your integration.
                  </p>
                </div>
              </div>
              {session && (
                <div className="text-center mt-6">
                  <Link
                    href="/dashboard"
                    className="inline-flex items-center px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 transition-colors"
                  >
                    View News
                    <svg
                      className="w-4 h-4 ml-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t dark:bg-gray-900 dark:border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-gray-600 dark:text-gray-400">
            © {new Date().getFullYear()} {APP_CONFIG.name}. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
