# Payment Integration Project

A payment integration solution built with Next.js, featuring secure payment processing and a user-friendly interface.

## Features

- User Authentication
- Latest News access (INDIAN/WORLD)
- Subscriptions
- Stripe Payment Integration
- Payment Verification
- Responsive design

## Tech Stack

- **Framework**: [Next.js](https://nextjs.org/)
- **Database**: [PostgreSQL](https://www.postgresql.org/)
- **ORM**: [Prisma](https://www.prisma.io/)
- **UI Components**: [shadcn/ui](https://ui.shadcn.com/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **Payments**: [Stripe](https://stripe.com/)

## Getting Started

### Prerequisites

- Node.js (version 18 or higher)
- npm (comes with Node.js)
- PostgreSQL database
- [stripe](https://stripe.com) Account for keys
- [NewsAPI](https://newsapi.org/) Account for keys
- Google Cloud Console account for OAuth credentials

### Installation

1. **Extract the Project**

   - Extract the provided zip file to your desired location
   - Open terminal/command prompt in the extracted directory

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Environment Setup**

   - Copy `.env.example` to `.env`
   - Fill in the required environment variables in `.env`:
     - Authentication secrets
     - Database connection string
     - Google OAuth credentials
     - News API key
     - Stripe API keys

4. **Database Setup**

   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Start the Development Server**
   ```bash
   npm run dev
   ```

Visit [http://localhost:3000](http://localhost:3000) to see the application in action.

## Testing

### Payment Testing

To test payment processing:

1. Use Stripe test card numbers:
   - Card Number: 4242 4242 4242 4242
   - Expiry: Any future date
   - CVC: Any 3 digits
2. Verify transaction status updates
3. vulnerable stripe test card numbers
   - 4000000000000002 - Card declined
   - 4000000000009995 - Insufficient funds
   - 4000000000003220 - 3D Secure authentication required

## Deployment

### Production Setup

1. **Database**

   - Set up a production PostgreSQL database
   - Update DATABASE_URL in production environment

2. **Stripe Setup**

   - Switch to Stripe live mode
   - Update Stripe API keys to production keys
   - Set up production webhook endpoints

3. **Environment Variables**

   - Configure all required environment variables in your hosting platform
   - Use production keys for all services

4. **Build and Deploy**
   ```bash
   npm run build
   npm start
   ```
